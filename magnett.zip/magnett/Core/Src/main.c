/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : MLX90393 I2C Test - Qwiic Version (Corrected)
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include <stdio.h>
#include <string.h>
#include "gpio.h"
#include "i2c.h"
#include "usart.h"

/* Private variables ---------------------------------------------------------*/
#define MLX90393_ADDR         (0x0C << 1)  // Qwiic MLX90393 = 0x0C (shifted for HAL)
#define CMD_EX                0x80         // Exit mode
#define CMD_NOP               0x00         // No operation
#define CMD_SM_XYZ            0x3F         // Start measurement: X/Y/Z
#define CMD_RM                0x4E         // Read measurement

uint8_t status;
int16_t magX, magY, magZ;

/* Function Prototypes */
void SystemClock_Config(void);
void Error_Handler(void);

/* Send a command over I2C */
void sendCommand(uint8_t* cmd, uint8_t tx_len, uint8_t* response, uint8_t rx_len) {
    if (HAL_I2C_Master_Transmit(&hi2c1, MLX90393_ADDR, cmd, tx_len, HAL_MAX_DELAY) != HAL_OK) {
        *response = 0xFF;
        return;
    }
    HAL_Delay(5);  // Short delay
    if (rx_len > 0) {
        HAL_I2C_Master_Receive(&hi2c1, MLX90393_ADDR, response, rx_len, HAL_MAX_DELAY);
    }
}

/* Read XYZ measurement from sensor */
uint8_t readMeasurementXYZ(int16_t* x, int16_t* y, int16_t* z) {
    uint8_t cmd_sm = CMD_SM_XYZ;
    uint8_t cmd_rm = CMD_RM;
    uint8_t resp[7] = {0};

    // Start measurement
    if (HAL_I2C_Master_Transmit(&hi2c1, MLX90393_ADDR, &cmd_sm, 1, HAL_MAX_DELAY) != HAL_OK)
        return 0;

    HAL_Delay(20);  // Wait for measurement to complete (>2.5ms recommended)

    // Read measurement
    if (HAL_I2C_Master_Transmit(&hi2c1, MLX90393_ADDR, &cmd_rm, 1, HAL_MAX_DELAY) != HAL_OK)
        return 0;

    if (HAL_I2C_Master_Receive(&hi2c1, MLX90393_ADDR, resp, 7, HAL_MAX_DELAY) != HAL_OK)
        return 0;

    status = resp[0];
    *x = (int16_t)(((uint16_t)resp[1] << 8) | resp[2]);
    *y = (int16_t)(((uint16_t)resp[3] << 8) | resp[4]);
    *z = (int16_t)(((uint16_t)resp[5] << 8) | resp[6]);

    return 1;
}

int main(void)
{
  HAL_Init();
  SystemClock_Config();

  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();

  printf("=== MLX90393 Qwiic Test Start ===\r\n");

  // Send EX (wake from sleep)
  uint8_t ex_cmd = CMD_EX;
  uint8_t resp[2] = {0};
  sendCommand(&ex_cmd, 1, resp, 1);
  if (resp[0] != 0xFF)
    printf("✅ Wake-up (EX) command sent (status: 0x%02X)\r\n", resp[0]);
  else
    printf("❌ Wake-up (EX) failed\r\n");

  // Send NOP to confirm status
  uint8_t nop_cmd = CMD_NOP;
  sendCommand(&nop_cmd, 1, resp, 1);
  if (resp[0] != 0xFF)
    printf("✅ NOP Status: 0x%02X\r\n", resp[0]);
  else
    printf("❌ NOP command failed\r\n");

  // Main loop
  while (1)
  {
    if (readMeasurementXYZ(&magX, &magY, &magZ)) {
        printf("Magnetic X: %d, Y: %d, Z: %d\r\n", magX, magY, magZ);
    } else {
        printf("❌ Failed to read measurement (SM/RM error)\r\n");
    }

    HAL_Delay(500);  // Read every 500ms
  }
}

/* System Clock Configuration */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              | RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) {
    Error_Handler();
  }
}

/* Error Handler */
void Error_Handler(void)
{
  __disable_irq();
  while (1) {
    printf("❌ Error_Handler triggered\r\n");
    HAL_Delay(1000);
  }
}
